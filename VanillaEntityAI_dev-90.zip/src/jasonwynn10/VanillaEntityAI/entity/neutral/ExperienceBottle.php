<?php
declare(strict_types=1);
namespace jasonwynn10\VanillaEntityAI\entity\neutral;

class ExperienceBottle extends \pocketmine\entity\projectile\ExperienceBottle {
}