<?php
declare(strict_types=1);
namespace jasonwynn10\VanillaEntityAI\entity\neutral;

class EnderPearl extends \pocketmine\entity\projectile\EnderPearl {
}