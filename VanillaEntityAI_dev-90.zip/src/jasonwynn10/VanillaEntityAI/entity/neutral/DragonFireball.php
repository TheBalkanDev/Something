<?php
declare(strict_types=1);
namespace jasonwynn10\VanillaEntityAI\entity\neutral;

use pocketmine\entity\projectile\Projectile;

class DragonFireball extends Projectile {
}