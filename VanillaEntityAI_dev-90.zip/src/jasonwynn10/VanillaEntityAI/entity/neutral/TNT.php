<?php
declare(strict_types=1);
namespace jasonwynn10\VanillaEntityAI\entity\neutral;

use pocketmine\entity\object\PrimedTNT;

class TNT extends PrimedTNT {
}