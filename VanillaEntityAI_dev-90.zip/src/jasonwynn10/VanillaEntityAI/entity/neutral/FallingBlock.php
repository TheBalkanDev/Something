<?php
declare(strict_types=1);
namespace jasonwynn10\VanillaEntityAI\entity\neutral;

class FallingBlock extends \pocketmine\entity\object\FallingBlock {
}