<?php
declare(strict_types=1);
namespace jasonwynn10\VanillaEntityAI\entity\neutral;

class ExperienceOrb extends \pocketmine\entity\object\ExperienceOrb {
}